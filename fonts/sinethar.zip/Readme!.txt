By installing or using this font, you are agree to the Product Usage Agreement:

1. This font for PERSONAL USE. No commercial use allowed!
2. If you want to use this font for commercial use you must buy a commercial license.
3. LINK TO PURCHASE COMMERSIAL LICENSE:

===========================================================

https://hanzelspace.com/product/sinethar-bold-script/

===========================================================


ATTENTION :


WARNING!!!
PENGGUNAAN FONT UNTUK KOMERSIL TANPA MEMBELI LISENSI 
RESMI
DARI hanzelspace.com MAKA DIKENAKAN BIAYA PEMBELIAN LISENSI 
MINIMAL 5X DARI HARGA LISENSI !!!!

IMPORTANT NOTES FOR Refita Font FONT USERS:

USE OF FONT FOR COMMERCIAL WITHOUT BUYING OFFICIAL LICENSE
FROM hanzelspace.com THEN PURCHASE FEES FOR PURCHASE LICENSE 
OF 5X MINIMUM LICENSE FROM THE LICENSE !!!!

===========================================================


to DONATE click here:
yodikdesigner@yahoo.com

if you need more detailed information you can contact me at:
hanzelgraphic@gmail.com


Thanks,
Hanzel Space